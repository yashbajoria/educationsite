var x = document.getElementById("demo").value;
if(x=='guwahati'){
document.getElementById("test1").href = "guwahati.html";

}
if(x=='silchar'){
document.getElementById("test1").href = "silchar.html";
}
